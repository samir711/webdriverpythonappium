#write a File
fw=open("d:\\write.txt", "w") # file name, and mode in which we wish to open the file.
fw.write("Hello how are you!")
fw.write("\n")
fw.close() # closing the file. 