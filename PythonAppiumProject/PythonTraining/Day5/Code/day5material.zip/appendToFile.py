#append a File
fw=open("d:\\write.txt", "a+") #append and read
fw.write("i am good how about you!")
fw.close()